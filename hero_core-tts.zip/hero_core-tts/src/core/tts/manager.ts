import { TTSEngine } from './types';
import { TTSOptions, AudioResult } from '../models/types';
import { KokoroEngine } from './kokoro';
import { WebSpeechEngine } from './fallback';

export class TTSManager {
  private static instance: TTSManager;
  private currentEngine: TTSEngine | null = null;
  private engines: Map<string, TTSEngine> = new Map();

  private constructor() {
    this.engines.set('kokoro', new KokoroEngine());
    this.engines.set('webspeech', new WebSpeechEngine());
  }

  static getInstance(): TTSManager {
    if (!TTSManager.instance) {
      TTSManager.instance = new TTSManager();
    }
    return TTSManager.instance;
  }

  async initializeEngine(engineName: string): Promise<void> {
    const engine = this.engines.get(engineName);
    if (!engine) {
      throw new Error(`Engine ${engineName} not found`);
    }

    if (this.currentEngine) {
      this.currentEngine.cleanup();
    }

    await engine.initialize();
    this.currentEngine = engine;
  }

  async synthesize(options: TTSOptions): Promise<AudioResult> {
    if (!this.currentEngine || !this.currentEngine.isReady()) {
      await this.initializeEngine('webspeech');
    }

    return this.currentEngine!.synthesize(options);
  }

  getCurrentEngine(): TTSEngine | null {
    return this.currentEngine;
  }

  cleanup(): void {
    if (this.currentEngine) {
      this.currentEngine.cleanup();
      this.currentEngine = null;
    }
  }
}

export const ttsManager = TTSManager.getInstance();
