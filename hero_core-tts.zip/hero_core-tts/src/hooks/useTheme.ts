import { useState, useEffect } from 'react';
import { getSettings, saveSettings } from '@/core/storage/settings';

export const useTheme = () => {
  const [theme, setTheme] = useState<'light' | 'dark' | 'system'>('system');

  useEffect(() => {
    getSettings().then((settings) => {
      setTheme(settings.theme);
      applyTheme(settings.theme);
    });
  }, []);

  const applyTheme = (theme: 'light' | 'dark' | 'system') => {
    const root = document.documentElement;
    
    if (theme === 'system') {
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      root.classList.toggle('dark', prefersDark);
    } else {
      root.classList.toggle('dark', theme === 'dark');
    }
  };

  const updateTheme = async (newTheme: 'light' | 'dark' | 'system') => {
    setTheme(newTheme);
    applyTheme(newTheme);
    await saveSettings({ theme: newTheme });
  };

  return { theme, updateTheme };
};
