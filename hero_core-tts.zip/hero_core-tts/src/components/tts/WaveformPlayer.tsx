import { useState, useRef, useEffect } from 'react';
import { Play, Pause, Download } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { formatDuration } from '@/lib/utils';

interface WaveformPlayerProps {
  audioBlob: Blob;
  duration: number;
}

export const WaveformPlayer = ({ audioBlob, duration }: WaveformPlayerProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const audioRef = useRef<HTMLAudioElement>(null);
  const audioUrl = useRef<string | null>(null);

  useEffect(() => {
    if (audioUrl.current) {
      URL.revokeObjectURL(audioUrl.current);
    }
    audioUrl.current = URL.createObjectURL(audioBlob);
    
    if (audioRef.current) {
      audioRef.current.src = audioUrl.current;
    }

    return () => {
      if (audioUrl.current) {
        URL.revokeObjectURL(audioUrl.current);
      }
    };
  }, [audioBlob]);

  const togglePlayPause = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play();
    }
    setIsPlaying(!isPlaying);
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setCurrentTime(audioRef.current.currentTime);
    }
  };

  const handleEnded = () => {
    setIsPlaying(false);
    setCurrentTime(0);
  };

  const handleDownload = () => {
    if (!audioUrl.current) return;
    const a = document.createElement('a');
    a.href = audioUrl.current;
    a.download = `tts-${Date.now()}.wav`;
    a.click();
  };

  return (
    <div className="space-y-3">
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleEnded}
        className="hidden"
      />
      
      <div className="flex items-center gap-4">
        <Button onClick={togglePlayPause} size="sm">
          {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
        </Button>
        
        <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary-600 transition-all"
            style={{ width: `${(currentTime / duration) * 100}%` }}
          />
        </div>
        
        <span className="text-sm text-gray-600 font-mono">
          {formatDuration(currentTime)} / {formatDuration(duration)}
        </span>
        
        <Button onClick={handleDownload} variant="outline" size="sm">
          <Download className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};
