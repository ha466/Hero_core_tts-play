import { useState, useEffect, useCallback } from 'react';
import {
  getTTSHistory,
  addTTSHistory,
  deleteTTSHistory,
  clearTTSHistory,
  getLLMHistory,
  addLLMHistory,
  deleteLLMHistory,
  clearLLMHistory,
  getAdventures,
  addAdventure,
  deleteAdventure,
  getAdventureById,
  updateAdventure,
} from '@/core/storage/history';
import { TTSHistoryEntry, LLMHistoryEntry, AdventureEntry } from '@/core/storage/db';

export const useIndexedDB = () => {
  const [ttsHistory, setTTSHistory] = useState<TTSHistoryEntry[]>([]);
  const [llmHistory, setLLMHistory] = useState<LLMHistoryEntry[]>([]);
  const [adventures, setAdventures] = useState<AdventureEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshTTSHistory = useCallback(async () => {
    const history = await getTTSHistory();
    setTTSHistory(history);
  }, []);

  const refreshLLMHistory = useCallback(async () => {
    const history = await getLLMHistory();
    setLLMHistory(history);
  }, []);

  const refreshAdventures = useCallback(async () => {
    const advs = await getAdventures();
    setAdventures(advs);
  }, []);

  useEffect(() => {
    Promise.all([refreshTTSHistory(), refreshLLMHistory(), refreshAdventures()])
      .then(() => setLoading(false))
      .catch(console.error);
  }, [refreshTTSHistory, refreshLLMHistory, refreshAdventures]);

  return {
    ttsHistory,
    llmHistory,
    adventures,
    loading,
    addTTSHistory: async (entry: Omit<TTSHistoryEntry, 'id'>) => {
      await addTTSHistory(entry);
      await refreshTTSHistory();
    },
    deleteTTSHistory: async (id: number) => {
      await deleteTTSHistory(id);
      await refreshTTSHistory();
    },
    clearTTSHistory: async () => {
      await clearTTSHistory();
      await refreshTTSHistory();
    },
    addLLMHistory: async (entry: Omit<LLMHistoryEntry, 'id'>) => {
      await addLLMHistory(entry);
      await refreshLLMHistory();
    },
    deleteLLMHistory: async (id: number) => {
      await deleteLLMHistory(id);
      await refreshLLMHistory();
    },
    clearLLMHistory: async () => {
      await clearLLMHistory();
      await refreshLLMHistory();
    },
    addAdventure: async (entry: Omit<AdventureEntry, 'id'>) => {
      await addAdventure(entry);
      await refreshAdventures();
    },
    deleteAdventure: async (id: number) => {
      await deleteAdventure(id);
      await refreshAdventures();
    },
    getAdventureById,
    updateAdventure: async (id: number, entry: AdventureEntry) => {
      await updateAdventure(id, entry);
      await refreshAdventures();
    },
  };
};
