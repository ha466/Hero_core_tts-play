import { useState, useCallback } from 'react';
import { LLMOptions, TextResult } from '@/core/models/types';

export const useLLM = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [result, setResult] = useState<TextResult | null>(null);

  const generate = useCallback(async (options: LLMOptions) => {
    setIsGenerating(true);
    setError(null);
    setResult(null);

    try {
      await new Promise(resolve => setTimeout(resolve, 1000));

      const mockResponse = `Generated response for: "${options.prompt.slice(0, 50)}..."\n\nOnce upon a time, in a digital realm far beyond the clouds, there lived an AI assistant who was passionate about helping users create amazing stories and adventures. This assistant had learned from countless tales, poems, and scripts, developing a deep understanding of narrative structure, character development, and engaging dialogue.\n\nThe assistant believed that every story had the power to transport readers to new worlds, evoke powerful emotions, and inspire profound thoughts. Whether crafting epic fantasy adventures, intimate character studies, or thrilling mysteries, the assistant approached each task with creativity and care.`;

      const textResult: TextResult = {
        type: 'text',
        text: mockResponse,
        tokenCount: mockResponse.split(' ').length,
      };

      setResult(textResult);
      return textResult;
    } catch (err) {
      const error = err instanceof Error ? err : new Error('LLM generation failed');
      setError(error);
      throw error;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return {
    generate,
    isGenerating,
    error,
    result,
    reset,
  };
};
