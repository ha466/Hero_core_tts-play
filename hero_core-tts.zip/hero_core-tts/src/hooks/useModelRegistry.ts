import { useMemo } from 'react';
import {
  modelRegistry,
  getModelById,
  getModelsByType,
  getModelsByHardware,
  getRecommendedModels,
} from '@/core/models/registry';
import { ModelType, HardwareTier } from '@/core/models/types';

export const useModelRegistry = () => {
  const allModels = useMemo(() => modelRegistry, []);

  const getById = useMemo(() => getModelById, []);
  const getByType = useMemo(() => getModelsByType, []);
  const getByHardware = useMemo(() => getModelsByHardware, []);
  const getRecommended = useMemo(() => getRecommendedModels, []);

  return {
    allModels,
    getById,
    getByType,
    getByHardware,
    getRecommended,
  };
};
