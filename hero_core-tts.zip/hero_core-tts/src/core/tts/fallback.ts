import { BaseTTSEngine } from './engine';
import { TTSOptions, AudioResult } from '../models/types';

export class WebSpeechEngine extends BaseTTSEngine {
  name = 'WebSpeech';
  private synthesis: SpeechSynthesis | null = null;

  async initialize(): Promise<void> {
    if (!('speechSynthesis' in window)) {
      throw new Error('Web Speech API not supported');
    }
    this.synthesis = window.speechSynthesis;
    this.ready = true;
  }

  async synthesize(options: TTSOptions): Promise<AudioResult> {
    if (!this.ready || !this.synthesis) {
      throw new Error('Engine not initialized');
    }

    return new Promise((resolve, reject) => {
      const utterance = new SpeechSynthesisUtterance(options.text);
      
      const voices = this.synthesis!.getVoices();
      if (options.voiceId && voices.length > 0) {
        const voice = voices.find(v => v.name === options.voiceId) || voices[0];
        utterance.voice = voice;
      }

      if (options.speed) utterance.rate = options.speed;
      if (options.pitch) utterance.pitch = options.pitch;
      if (options.volume) utterance.volume = options.volume;

      const audioContext = new AudioContext();
      const destination = audioContext.createMediaStreamDestination();
      const mediaRecorder = new MediaRecorder(destination.stream);
      const chunks: Blob[] = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunks.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(chunks, { type: 'audio/webm' });
        resolve({
          type: 'audio',
          audioBlob,
          duration: utterance.text.length * 0.05,
          format: 'webm',
        });
      };

      utterance.onend = () => {
        mediaRecorder.stop();
        audioContext.close();
      };

      utterance.onerror = (event) => {
        reject(new Error(`Speech synthesis failed: ${event.error}`));
      };

      mediaRecorder.start();
      this.synthesis!.speak(utterance);
    });
  }

  cleanup(): void {
    if (this.synthesis) {
      this.synthesis.cancel();
    }
    super.cleanup();
  }
}
