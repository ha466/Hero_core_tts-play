import { useState, useEffect } from 'react';
import { detectHardwareProfile, HardwareProfile } from '@/core/hardware/detection';

export const useHardwareProfile = () => {
  const [profile, setProfile] = useState<HardwareProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    detectHardwareProfile()
      .then((detectedProfile) => {
        setProfile(detectedProfile);
        setLoading(false);
      })
      .catch((err) => {
        setError(err);
        setLoading(false);
      });
  }, []);

  return { profile, loading, error };
};
