import { getDB, TTSHistoryEntry, LLMHistoryEntry, AdventureEntry } from './db';

export const addTTSHistory = async (entry: Omit<TTSHistoryEntry, 'id'>): Promise<number> => {
  const db = await getDB();
  return await db.add('ttsHistory', { ...entry, id: undefined });
};

export const getTTSHistory = async (limit = 50): Promise<TTSHistoryEntry[]> => {
  const db = await getDB();
  const tx = db.transaction('ttsHistory', 'readonly');
  const index = tx.store.index('timestamp');
  const entries = await index.getAll();
  return entries.reverse().slice(0, limit);
};

export const deleteTTSHistory = async (id: number): Promise<void> => {
  const db = await getDB();
  await db.delete('ttsHistory', id);
};

export const clearTTSHistory = async (): Promise<void> => {
  const db = await getDB();
  await db.clear('ttsHistory');
};

export const addLLMHistory = async (entry: Omit<LLMHistoryEntry, 'id'>): Promise<number> => {
  const db = await getDB();
  return await db.add('llmHistory', { ...entry, id: undefined });
};

export const getLLMHistory = async (limit = 50): Promise<LLMHistoryEntry[]> => {
  const db = await getDB();
  const tx = db.transaction('llmHistory', 'readonly');
  const index = tx.store.index('timestamp');
  const entries = await index.getAll();
  return entries.reverse().slice(0, limit);
};

export const deleteLLMHistory = async (id: number): Promise<void> => {
  const db = await getDB();
  await db.delete('llmHistory', id);
};

export const clearLLMHistory = async (): Promise<void> => {
  const db = await getDB();
  await db.clear('llmHistory');
};

export const addAdventure = async (entry: Omit<AdventureEntry, 'id'>): Promise<number> => {
  const db = await getDB();
  return await db.add('adventures', { ...entry, id: undefined });
};

export const getAdventures = async (): Promise<AdventureEntry[]> => {
  const db = await getDB();
  const tx = db.transaction('adventures', 'readonly');
  const index = tx.store.index('timestamp');
  const entries = await index.getAll();
  return entries.reverse();
};

export const getAdventureById = async (id: number): Promise<AdventureEntry | undefined> => {
  const db = await getDB();
  return await db.get('adventures', id);
};

export const updateAdventure = async (id: number, entry: AdventureEntry): Promise<void> => {
  const db = await getDB();
  await db.put('adventures', { ...entry, id });
};

export const deleteAdventure = async (id: number): Promise<void> => {
  const db = await getDB();
  await db.delete('adventures', id);
};

export const clearAdventures = async (): Promise<void> => {
  const db = await getDB();
  await db.clear('adventures');
};
