import { openDB, DBSchema, IDBPDatabase } from 'idb';

export interface TTSHistoryEntry {
  id?: number;
  text: string;
  voiceId: string;
  modelId: string;
  audioBlob?: Blob;
  duration?: number;
  timestamp: number;
}

export interface LLMHistoryEntry {
  id?: number;
  prompt: string;
  response: string;
  modelId: string;
  tokenCount?: number;
  timestamp: number;
}

export interface AdventureEntry {
  id?: number;
  title: string;
  chapters: {
    title: string;
    content: string;
    audioBlob?: Blob;
  }[];
  modelId: string;
  voiceId?: string;
  timestamp: number;
}

export interface AppSettings {
  theme: 'light' | 'dark' | 'system';
  defaultTTSModel?: string;
  defaultLLMModel?: string;
  defaultVoice?: string;
  autoPlayAudio: boolean;
  performanceMode?: 'low' | 'medium' | 'high';
}

interface HeroCoreDB extends DBSchema {
  ttsHistory: {
    key: number;
    value: TTSHistoryEntry;
    indexes: { timestamp: number; modelId: string };
  };
  llmHistory: {
    key: number;
    value: LLMHistoryEntry;
    indexes: { timestamp: number; modelId: string };
  };
  adventures: {
    key: number;
    value: AdventureEntry;
    indexes: { timestamp: number; title: string };
  };
  audioBlobs: {
    key: string;
    value: Blob;
  };
  settings: {
    key: string;
    value: AppSettings;
  };
}

const DB_NAME = 'hero-core-tts';
const DB_VERSION = 1;

let dbInstance: IDBPDatabase<HeroCoreDB> | null = null;

export const initDB = async (): Promise<IDBPDatabase<HeroCoreDB>> => {
  if (dbInstance) {
    return dbInstance;
  }

  dbInstance = await openDB<HeroCoreDB>(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('ttsHistory')) {
        const ttsStore = db.createObjectStore('ttsHistory', {
          keyPath: 'id',
          autoIncrement: true,
        });
        ttsStore.createIndex('timestamp', 'timestamp');
        ttsStore.createIndex('modelId', 'modelId');
      }

      if (!db.objectStoreNames.contains('llmHistory')) {
        const llmStore = db.createObjectStore('llmHistory', {
          keyPath: 'id',
          autoIncrement: true,
        });
        llmStore.createIndex('timestamp', 'timestamp');
        llmStore.createIndex('modelId', 'modelId');
      }

      if (!db.objectStoreNames.contains('adventures')) {
        const adventureStore = db.createObjectStore('adventures', {
          keyPath: 'id',
          autoIncrement: true,
        });
        adventureStore.createIndex('timestamp', 'timestamp');
        adventureStore.createIndex('title', 'title');
      }

      if (!db.objectStoreNames.contains('audioBlobs')) {
        db.createObjectStore('audioBlobs');
      }

      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings');
      }
    },
  });

  return dbInstance;
};

export const getDB = async (): Promise<IDBPDatabase<HeroCoreDB>> => {
  if (!dbInstance) {
    return await initDB();
  }
  return dbInstance;
};
