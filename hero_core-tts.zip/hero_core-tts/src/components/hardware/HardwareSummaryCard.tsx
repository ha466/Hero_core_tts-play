import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { Cpu, HardDrive, Zap } from 'lucide-react';
import { HardwareProfile } from '@/core/hardware/detection';

interface HardwareSummaryCardProps {
  profile: HardwareProfile;
}

export const HardwareSummaryCard = ({ profile }: HardwareSummaryCardProps) => {
  const tierColors = {
    low: 'warning',
    medium: 'info',
    high: 'success',
  } as const;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Hardware Profile</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Performance Tier</span>
          <Badge variant={tierColors[profile.tier]}>{profile.tier.toUpperCase()}</Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Cpu className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-600">CPU Cores:</span>
            <span className="text-sm font-medium">{profile.cpuCores}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-600">Memory:</span>
            <span className="text-sm font-medium">{profile.memory} GB</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-gray-500" />
            <span className="text-sm text-gray-600">Device Type:</span>
            <span className="text-sm font-medium capitalize">{profile.deviceType}</span>
          </div>
        </div>

        <div className="pt-3 border-t">
          <div className="flex gap-2">
            {profile.hasWebGPU && <Badge variant="success">WebGPU</Badge>}
            {profile.hasWASM && <Badge variant="success">WASM</Badge>}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
