import { useNavigate } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Mic, FileText, BookOpen, TrendingUp } from 'lucide-react';
import { useIndexedDB } from '@/hooks/useIndexedDB';
import { useHardwareProfile } from '@/hooks/useHardwareProfile';
import { HardwareSummaryCard } from '@/components/hardware/HardwareSummaryCard';

export const Dashboard = () => {
  const navigate = useNavigate();
  const { ttsHistory, llmHistory, adventures, loading } = useIndexedDB();
  const { profile } = useHardwareProfile();

  const stats = [
    { label: 'TTS Generations', value: ttsHistory.length, icon: Mic, color: 'text-primary-600' },
    { label: 'Stories Created', value: llmHistory.length, icon: FileText, color: 'text-accent-600' },
    { label: 'Adventures', value: adventures.length, icon: BookOpen, color: 'text-green-600' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">Welcome to HERO Core TTS</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.label}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className="text-3xl font-bold text-gray-900 mt-1">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-lg bg-gray-50 ${stat.color}`}>
                    <Icon className="w-8 h-8" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button onClick={() => navigate('/tts')} className="w-full justify-start">
              <Mic className="w-4 h-4" />
              Generate Speech
            </Button>
            <Button onClick={() => navigate('/story')} variant="secondary" className="w-full justify-start">
              <FileText className="w-4 h-4" />
              Create Story
            </Button>
            <Button onClick={() => navigate('/adventure')} variant="outline" className="w-full justify-start">
              <BookOpen className="w-4 h-4" />
              New Adventure
            </Button>
          </CardContent>
        </Card>

        {profile && <HardwareSummaryCard profile={profile} />}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-gray-500">Loading...</p>
          ) : ttsHistory.length === 0 && llmHistory.length === 0 ? (
            <p className="text-gray-500">No recent activity. Start by generating some speech or creating a story!</p>
          ) : (
            <div className="space-y-2">
              {ttsHistory.slice(0, 5).map((entry) => (
                <div key={entry.id} className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm font-medium text-gray-900 truncate">{entry.text}</p>
                  <p className="text-xs text-gray-500 mt-1">TTS • {new Date(entry.timestamp).toLocaleString()}</p>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
