import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Badge } from '@/components/ui/Badge';
import { BookOpen, Plus, Play } from 'lucide-react';
import { useIndexedDB } from '@/hooks/useIndexedDB';

export const AdventureMode = () => {
  const { adventures, addAdventure } = useIndexedDB();
  const [showWizard, setShowWizard] = useState(false);
  const [adventureTitle, setAdventureTitle] = useState('');
  const [chapterCount, setChapterCount] = useState(3);

  const handleCreateAdventure = async () => {
    if (!adventureTitle.trim()) return;

    const chapters = Array.from({ length: chapterCount }, (_, i) => ({
      title: `Chapter ${i + 1}`,
      content: `Content for chapter ${i + 1}...`,
    }));

    await addAdventure({
      title: adventureTitle,
      chapters,
      modelId: 'llama-3.2-1b',
      timestamp: Date.now(),
    });

    setAdventureTitle('');
    setShowWizard(false);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Adventure Mode</h1>
          <p className="text-gray-600 mt-1">Create multi-chapter interactive adventures</p>
        </div>
        <Button onClick={() => setShowWizard(true)}>
          <Plus className="w-4 h-4" />
          New Adventure
        </Button>
      </div>

      {showWizard && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Adventure</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Adventure Title</label>
              <Input
                value={adventureTitle}
                onChange={(e) => setAdventureTitle(e.target.value)}
                placeholder="Enter adventure title..."
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Number of Chapters</label>
              <Input
                type="number"
                value={chapterCount}
                onChange={(e) => setChapterCount(parseInt(e.target.value))}
                min={1}
                max={10}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleCreateAdventure} disabled={!adventureTitle.trim()}>
                Create Adventure
              </Button>
              <Button onClick={() => setShowWizard(false)} variant="outline">
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {adventures.length === 0 ? (
          <Card className="md:col-span-2">
            <CardContent className="p-12 text-center">
              <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No adventures yet. Create your first adventure!</p>
            </CardContent>
          </Card>
        ) : (
          adventures.map((adventure) => (
            <Card key={adventure.id} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="text-lg">{adventure.title}</CardTitle>
                  <Badge variant="info">{adventure.chapters.length} chapters</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 mb-4">
                  Created {new Date(adventure.timestamp).toLocaleDateString()}
                </p>
                <Button size="sm" variant="outline" className="w-full">
                  <Play className="w-4 h-4" />
                  Continue
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};
