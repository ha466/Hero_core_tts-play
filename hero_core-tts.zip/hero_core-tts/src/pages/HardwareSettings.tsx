import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Select } from '@/components/ui/Select';
import { HardwareSummaryCard } from '@/components/hardware/HardwareSummaryCard';
import { useHardwareProfile } from '@/hooks/useHardwareProfile';
import { useAppStore } from '@/stores/appStore';
import { useModelRegistry } from '@/hooks/useModelRegistry';
import { Badge } from '@/components/ui/Badge';
import { Zap, AlertCircle } from 'lucide-react';

export const HardwareSettings = () => {
  const { profile, loading } = useHardwareProfile();
  const { performanceMode, setPerformanceMode } = useAppStore();
  const { getRecommended } = useModelRegistry();

  const recommendedTTS = profile ? getRecommended(profile.tier, 'tts') : [];
  const recommendedLLM = profile ? getRecommended(profile.tier, 'llm') : [];

  if (loading || !profile) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-gray-500">Detecting hardware...</p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Hardware Settings</h1>
        <p className="text-gray-600 mt-1">Configure performance and view recommendations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <HardwareSummaryCard profile={profile} />

        <Card>
          <CardHeader>
            <CardTitle>Performance Mode</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Mode</label>
              <Select value={performanceMode} onChange={(e) => setPerformanceMode(e.target.value as any)}>
                <option value="low">Low - Minimal resource usage</option>
                <option value="medium">Medium - Balanced performance</option>
                <option value="high">High - Maximum quality</option>
              </Select>
            </div>

            <div className="p-4 bg-blue-50 rounded-lg flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900">
                <p className="font-medium mb-1">Recommended: {profile.tier}</p>
                <p>Based on your hardware, we recommend using {profile.tier}-tier models for optimal performance.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recommended TTS Models</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recommendedTTS.map((model) => (
              <div key={model.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{model.displayName}</p>
                  <p className="text-sm text-gray-600">{model.description}</p>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="info">{model.qualityTier}</Badge>
                    <Badge variant="default">{model.approxParams}</Badge>
                    {model.supportsWebGPU && <Badge variant="success">WebGPU</Badge>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recommended LLM Models</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recommendedLLM.map((model) => (
              <div key={model.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{model.displayName}</p>
                  <p className="text-sm text-gray-600">{model.description}</p>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="info">{model.qualityTier}</Badge>
                    <Badge variant="default">{model.approxParams}</Badge>
                    {model.contextLength && <Badge variant="default">{model.contextLength} ctx</Badge>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
