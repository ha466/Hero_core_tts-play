import { Select } from '@/components/ui/Select';
import { Badge } from '@/components/ui/Badge';
import { ModelConfig } from '@/core/models/types';
import { formatBytes } from '@/lib/utils';

interface ModelSelectorProps {
  models: ModelConfig[];
  selectedModel: string | null;
  onModelChange: (modelId: string) => void;
}

export const ModelSelector = ({ models, selectedModel, onModelChange }: ModelSelectorProps) => {
  const selected = models.find((m) => m.id === selectedModel);

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-gray-700">Model</label>
      <Select value={selectedModel || ''} onChange={(e) => onModelChange(e.target.value)}>
        <option value="">Select a model</option>
        {models.map((model) => (
          <option key={model.id} value={model.id}>
            {model.displayName} ({model.approxParams})
          </option>
        ))}
      </Select>
      {selected && (
        <div className="flex gap-2 flex-wrap">
          <Badge variant="info">{selected.qualityTier}</Badge>
          <Badge variant="default">{formatBytes(selected.approxSizeMB * 1024 * 1024)}</Badge>
          {selected.supportsWebGPU && <Badge variant="success">WebGPU</Badge>}
        </div>
      )}
    </div>
  );
};
