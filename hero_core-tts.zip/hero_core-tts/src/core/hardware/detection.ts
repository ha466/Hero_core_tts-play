import { HardwareTier } from '../models/types';

export interface HardwareProfile {
  tier: HardwareTier;
  hasWebGPU: boolean;
  hasWASM: boolean;
  deviceType: 'mobile' | 'tablet' | 'desktop';
  cpuCores: number;
  memory: number;
  gpuInfo?: string;
  performanceLevel: number;
}

export const detectWebGPU = async (): Promise<boolean> => {
  if (!('gpu' in navigator)) {
    return false;
  }
  try {
    const adapter = await navigator.gpu?.requestAdapter();
    return !!adapter;
  } catch {
    return false;
  }
};

export const detectWASM = (): boolean => {
  try {
    if (typeof WebAssembly === 'object' && typeof WebAssembly.instantiate === 'function') {
      const module = new WebAssembly.Module(Uint8Array.of(0x0, 0x61, 0x73, 0x6d, 0x01, 0x00, 0x00, 0x00));
      return module instanceof WebAssembly.Module;
    }
  } catch {
    return false;
  }
  return false;
};

export const detectDeviceType = (): 'mobile' | 'tablet' | 'desktop' => {
  const ua = navigator.userAgent.toLowerCase();
  const isMobile = /android|webos|iphone|ipod|blackberry|iemobile|opera mini/i.test(ua);
  const isTablet = /ipad|android(?!.*mobile)|tablet/i.test(ua);

  if (isTablet) return 'tablet';
  if (isMobile) return 'mobile';
  return 'desktop';
};

export const detectCPUCores = (): number => {
  return navigator.hardwareConcurrency || 4;
};

export const estimateMemory = (): number => {
  if ('deviceMemory' in navigator) {
    return (navigator as { deviceMemory?: number }).deviceMemory || 4;
  }
  return 4;
};

export const estimatePerformanceLevel = (
  deviceType: string,
  cores: number,
  memory: number,
  hasWebGPU: boolean
): number => {
  let score = 0;

  if (deviceType === 'desktop') score += 40;
  else if (deviceType === 'tablet') score += 20;
  else score += 10;

  if (cores >= 8) score += 30;
  else if (cores >= 4) score += 20;
  else score += 10;

  if (memory >= 8) score += 20;
  else if (memory >= 4) score += 10;
  else score += 5;

  if (hasWebGPU) score += 10;

  return score;
};

export const determineHardwareTier = (performanceLevel: number): HardwareTier => {
  if (performanceLevel >= 75) return 'high';
  if (performanceLevel >= 50) return 'medium';
  return 'low';
};

export const detectHardwareProfile = async (): Promise<HardwareProfile> => {
  const hasWebGPU = await detectWebGPU();
  const hasWASM = detectWASM();
  const deviceType = detectDeviceType();
  const cpuCores = detectCPUCores();
  const memory = estimateMemory();
  const performanceLevel = estimatePerformanceLevel(deviceType, cpuCores, memory, hasWebGPU);
  const tier = determineHardwareTier(performanceLevel);

  let gpuInfo: string | undefined;
  if (hasWebGPU) {
    try {
      const adapter = await navigator.gpu?.requestAdapter();
      if (adapter) {
        gpuInfo = `WebGPU Adapter`;
      }
    } catch {
      gpuInfo = undefined;
    }
  }

  return {
    tier,
    hasWebGPU,
    hasWASM,
    deviceType,
    cpuCores,
    memory,
    gpuInfo,
    performanceLevel,
  };
};
