import { useState, useCallback } from 'react';
import { ttsManager } from '@/core/tts/manager';
import { TTSOptions, AudioResult } from '@/core/models/types';

export const useTTS = () => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [result, setResult] = useState<AudioResult | null>(null);

  const generate = useCallback(async (options: TTSOptions) => {
    setIsGenerating(true);
    setError(null);
    setResult(null);

    try {
      const audioResult = await ttsManager.synthesize(options);
      setResult(audioResult);
      return audioResult;
    } catch (err) {
      const error = err instanceof Error ? err : new Error('TTS generation failed');
      setError(error);
      throw error;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  const reset = useCallback(() => {
    setResult(null);
    setError(null);
  }, []);

  return {
    generate,
    isGenerating,
    error,
    result,
    reset,
  };
};
