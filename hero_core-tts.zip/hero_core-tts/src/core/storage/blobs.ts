import { getDB } from './db';

export const saveAudioBlob = async (key: string, blob: Blob): Promise<void> => {
  const db = await getDB();
  await db.put('audioBlobs', blob, key);
};

export const getAudioBlob = async (key: string): Promise<Blob | undefined> => {
  const db = await getDB();
  return await db.get('audioBlobs', key);
};

export const deleteAudioBlob = async (key: string): Promise<void> => {
  const db = await getDB();
  await db.delete('audioBlobs', key);
};

export const clearAudioBlobs = async (): Promise<void> => {
  const db = await getDB();
  await db.clear('audioBlobs');
};
