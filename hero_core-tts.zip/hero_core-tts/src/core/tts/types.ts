import { TTSOptions, AudioResult } from '../models/types';

export interface TTSEngine {
  name: string;
  initialize(): Promise<void>;
  isReady(): boolean;
  synthesize(options: TTSOptions): Promise<AudioResult>;
  cleanup(): void;
}

export interface WAVHeader {
  sampleRate: number;
  numChannels: number;
  bitsPerSample: number;
}
