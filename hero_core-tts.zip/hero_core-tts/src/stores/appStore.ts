import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AppState {
  selectedTTSModel: string | null;
  selectedLLMModel: string | null;
  selectedVoice: string | null;
  performanceMode: 'low' | 'medium' | 'high';
  autoPlayAudio: boolean;
  setSelectedTTSModel: (modelId: string) => void;
  setSelectedLLMModel: (modelId: string) => void;
  setSelectedVoice: (voiceId: string) => void;
  setPerformanceMode: (mode: 'low' | 'medium' | 'high') => void;
  setAutoPlayAudio: (autoPlay: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      selectedTTSModel: null,
      selectedLLMModel: null,
      selectedVoice: null,
      performanceMode: 'medium',
      autoPlayAudio: true,
      setSelectedTTSModel: (modelId) => set({ selectedTTSModel: modelId }),
      setSelectedLLMModel: (modelId) => set({ selectedLLMModel: modelId }),
      setSelectedVoice: (voiceId) => set({ selectedVoice: voiceId }),
      setPerformanceMode: (mode) => set({ performanceMode: mode }),
      setAutoPlayAudio: (autoPlay) => set({ autoPlayAudio: autoPlay }),
    }),
    {
      name: 'hero-core-app-storage',
    }
  )
);
