import { Select } from '@/components/ui/Select';
import { ModelConfig, VoiceConfig } from '@/core/models/types';

interface VoiceSelectorProps {
  model: ModelConfig | null;
  selectedVoice: string | null;
  onVoiceChange: (voiceId: string) => void;
}

export const VoiceSelector = ({ model, selectedVoice, onVoiceChange }: VoiceSelectorProps) => {
  if (!model || !model.voices || model.voices.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-gray-700">Voice</label>
      <Select value={selectedVoice || ''} onChange={(e) => onVoiceChange(e.target.value)}>
        <option value="">Select a voice</option>
        {model.voices.map((voice) => (
          <option key={voice.id} value={voice.id}>
            {voice.name} {voice.gender && `(${voice.gender})`}
          </option>
        ))}
      </Select>
    </div>
  );
};
