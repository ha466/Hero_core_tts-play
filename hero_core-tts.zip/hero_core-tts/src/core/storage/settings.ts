import { getDB, AppSettings } from './db';

const SETTINGS_KEY = 'app-settings';

const defaultSettings: AppSettings = {
  theme: 'system',
  autoPlayAudio: true,
};

export const getSettings = async (): Promise<AppSettings> => {
  const db = await getDB();
  const settings = await db.get('settings', SETTINGS_KEY);
  return settings || defaultSettings;
};

export const saveSettings = async (settings: Partial<AppSettings>): Promise<void> => {
  const db = await getDB();
  const current = await getSettings();
  const updated = { ...current, ...settings };
  await db.put('settings', updated, SETTINGS_KEY);
};

export const resetSettings = async (): Promise<void> => {
  const db = await getDB();
  await db.put('settings', defaultSettings, SETTINGS_KEY);
};
