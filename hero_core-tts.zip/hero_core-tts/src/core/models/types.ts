export type ModelType = 'tts' | 'llm' | 'music' | 'voice_clone' | 'transcription' | 'other';
export type QualityTier = 'fast' | 'balanced' | 'high';
export type HardwareTier = 'low' | 'medium' | 'high';

export interface VoiceConfig {
  id: string;
  name: string;
  gender: 'male' | 'female' | 'neutral';
  accent?: string;
  style?: string[];
}

export interface ModelConfig {
  id: string;
  displayName: string;
  type: ModelType;
  approxParams: string;
  approxSizeMB: number;
  qualityTier: QualityTier;
  recommendedHardware: HardwareTier;
  supportsWebGPU: boolean;
  supportsWASM: boolean;
  tags: string[];
  description: string;
  supportsVoiceClone?: boolean;
  voices?: VoiceConfig[];
  contextLength?: number;
  loadConfig?: {
    modelId: string;
    quantization?: string;
  };
}

export interface TTSOptions {
  text: string;
  voiceId?: string;
  speed?: number;
  pitch?: number;
  volume?: number;
}

export interface LLMOptions {
  prompt: string;
  maxTokens?: number;
  temperature?: number;
  topP?: number;
  stopSequences?: string[];
}

export interface AudioResult {
  type: 'audio';
  audioBlob: Blob;
  duration: number;
  format: string;
}

export interface TextResult {
  type: 'text';
  text: string;
  tokenCount?: number;
}

export type GenerationResult = AudioResult | TextResult;
