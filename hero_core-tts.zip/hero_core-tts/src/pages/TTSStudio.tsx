import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Slider } from '@/components/ui/Slider';
import { ModelSelector } from '@/components/tts/ModelSelector';
import { VoiceSelector } from '@/components/tts/VoiceSelector';
import { WaveformPlayer } from '@/components/tts/WaveformPlayer';
import { useModelRegistry } from '@/hooks/useModelRegistry';
import { useAppStore } from '@/stores/appStore';
import { useTTS } from '@/hooks/useTTS';
import { useIndexedDB } from '@/hooks/useIndexedDB';
import { Loader2 } from 'lucide-react';

export const TTSStudio = () => {
  const { getByType, getById } = useModelRegistry();
  const ttsModels = getByType('tts');
  const { selectedTTSModel, selectedVoice, setSelectedTTSModel, setSelectedVoice } = useAppStore();
  const { generate, isGenerating, result } = useTTS();
  const { addTTSHistory } = useIndexedDB();

  const [text, setText] = useState('');
  const [speed, setSpeed] = useState(1);
  const [pitch, setPitch] = useState(1);
  const [volume, setVolume] = useState(1);

  const selectedModel = selectedTTSModel ? getById(selectedTTSModel) : null;

  const handleGenerate = async () => {
    if (!text.trim() || !selectedTTSModel) return;

    const audioResult = await generate({
      text,
      voiceId: selectedVoice || undefined,
      speed,
      pitch,
      volume,
    });

    await addTTSHistory({
      text,
      voiceId: selectedVoice || '',
      modelId: selectedTTSModel,
      audioBlob: audioResult.audioBlob,
      duration: audioResult.duration,
      timestamp: Date.now(),
    });
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">TTS Studio</h1>
        <p className="text-gray-600 mt-1">Convert text to natural-sounding speech</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Text Input</CardTitle>
            </CardHeader>
            <CardContent>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter the text you want to convert to speech..."
                className="w-full h-40 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
              />
              <p className="text-sm text-gray-500 mt-2">{text.length} characters</p>
            </CardContent>
          </Card>

          {result && (
            <Card>
              <CardHeader>
                <CardTitle>Audio Output</CardTitle>
              </CardHeader>
              <CardContent>
                <WaveformPlayer audioBlob={result.audioBlob} duration={result.duration} />
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <ModelSelector
                models={ttsModels}
                selectedModel={selectedTTSModel}
                onModelChange={setSelectedTTSModel}
              />

              <VoiceSelector
                model={selectedModel}
                selectedVoice={selectedVoice}
                onVoiceChange={setSelectedVoice}
              />

              <Slider
                label="Speed"
                min={0.5}
                max={2}
                step={0.1}
                value={speed}
                onChange={(e) => setSpeed(parseFloat(e.target.value))}
              />

              <Slider
                label="Pitch"
                min={0.5}
                max={2}
                step={0.1}
                value={pitch}
                onChange={(e) => setPitch(parseFloat(e.target.value))}
              />

              <Slider
                label="Volume"
                min={0}
                max={1}
                step={0.1}
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
              />

              <Button
                onClick={handleGenerate}
                disabled={!text.trim() || !selectedTTSModel || isGenerating}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  'Generate Speech'
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
