import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Select } from '@/components/ui/Select';
import { ModelSelector } from '@/components/tts/ModelSelector';
import { useModelRegistry } from '@/hooks/useModelRegistry';
import { useAppStore } from '@/stores/appStore';
import { useLLM } from '@/hooks/useLLM';
import { useIndexedDB } from '@/hooks/useIndexedDB';
import { Loader2, Copy, Download } from 'lucide-react';

export const StoryGenerator = () => {
  const { getByType } = useModelRegistry();
  const llmModels = getByType('llm');
  const { selectedLLMModel, setSelectedLLMModel } = useAppStore();
  const { generate, isGenerating, result } = useLLM();
  const { addLLMHistory } = useIndexedDB();

  const [contentType, setContentType] = useState<'story' | 'poem' | 'script'>('story');
  const [genre, setGenre] = useState('fantasy');
  const [prompt, setPrompt] = useState('');
  const [maxTokens, setMaxTokens] = useState(500);

  const handleGenerate = async () => {
    if (!prompt.trim() || !selectedLLMModel) return;

    const fullPrompt = `Write a ${contentType} in the ${genre} genre: ${prompt}`;
    
    const textResult = await generate({
      prompt: fullPrompt,
      maxTokens,
      temperature: 0.8,
    });

    await addLLMHistory({
      prompt: fullPrompt,
      response: textResult.text,
      modelId: selectedLLMModel,
      tokenCount: textResult.tokenCount,
      timestamp: Date.now(),
    });
  };

  const handleCopy = () => {
    if (result) {
      navigator.clipboard.writeText(result.text);
    }
  };

  const handleDownload = () => {
    if (!result) return;
    const blob = new Blob([result.text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `story-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Story Generator</h1>
        <p className="text-gray-600 mt-1">Create stories, poems, and scripts with AI</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Prompt</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Content Type</label>
                  <Select value={contentType} onChange={(e) => setContentType(e.target.value as any)}>
                    <option value="story">Story</option>
                    <option value="poem">Poem</option>
                    <option value="script">Script</option>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Genre</label>
                  <Select value={genre} onChange={(e) => setGenre(e.target.value)}>
                    <option value="fantasy">Fantasy</option>
                    <option value="scifi">Sci-Fi</option>
                    <option value="mystery">Mystery</option>
                    <option value="romance">Romance</option>
                    <option value="horror">Horror</option>
                    <option value="adventure">Adventure</option>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Description</label>
                <textarea
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Describe what you want to create..."
                  className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 resize-none"
                />
              </div>
            </CardContent>
          </Card>

          {result && (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Generated Content</CardTitle>
                  <div className="flex gap-2">
                    <Button onClick={handleCopy} variant="outline" size="sm">
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button onClick={handleDownload} variant="outline" size="sm">
                      <Download className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="prose max-w-none">
                  <pre className="whitespace-pre-wrap font-sans text-gray-700">{result.text}</pre>
                </div>
                <p className="text-sm text-gray-500 mt-4">
                  {result.tokenCount} tokens
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <ModelSelector
                models={llmModels}
                selectedModel={selectedLLMModel}
                onModelChange={setSelectedLLMModel}
              />

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Max Length</label>
                <Input
                  type="number"
                  value={maxTokens}
                  onChange={(e) => setMaxTokens(parseInt(e.target.value))}
                  min={100}
                  max={2000}
                  step={100}
                />
              </div>

              <Button
                onClick={handleGenerate}
                disabled={!prompt.trim() || !selectedLLMModel || isGenerating}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  'Generate'
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};
